package ru.samsung.gamestudio.managers;

import com.badlogic.gdx.physics.box2d.*;

import ru.samsung.gamestudio.GameSession;
import ru.samsung.gamestudio.GameSettings;
import ru.samsung.gamestudio.objects.GameObject;
import ru.samsung.gamestudio.objects.ShipObject;
import ru.samsung.gamestudio.objects.TrashObject;

public class ContactManager {

    World world;
    private GameSession gameSession;

    public ContactManager(World world, GameSession gameSession) {
        this.world = world;
        this.gameSession = gameSession;

        world.setContactListener(new ContactListener() {
            @Override
            public void beginContact(Contact contact) {

                Fixture fixA = contact.getFixtureA();
                Fixture fixB = contact.getFixtureB();

                int cDef = fixA.getFilterData().categoryBits;
                int cDef2 = fixB.getFilterData().categoryBits;


                if ((cDef == GameSettings.TRASH_BIT && cDef2 == GameSettings.BULLET_BIT)
                        || (cDef2 == GameSettings.TRASH_BIT && cDef == GameSettings.BULLET_BIT)) {

                    ((GameObject) fixA.getUserData()).hit();
                    ((GameObject) fixB.getUserData()).hit();

                }


                if ((cDef == GameSettings.TRASH_BIT && cDef2 == GameSettings.SHIP_BIT)
                        || (cDef2 == GameSettings.TRASH_BIT && cDef == GameSettings.SHIP_BIT)) {

                    ((GameObject) fixA.getUserData()).hit();
                    ((GameObject) fixB.getUserData()).hit();


                    if (gameSession != null) {
                        gameSession.registerCollision();
                    }
                }
            }

            @Override
            public void endContact(Contact contact) {
            }

            @Override
            public void preSolve(Contact contact, Manifold oldManifold) {
            }

            @Override
            public void postSolve(Contact contact, ContactImpulse impulse) {
            }
        });

    }

}